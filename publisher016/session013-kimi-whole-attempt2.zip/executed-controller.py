"""Run a fixed, label-independent half of MMMU on the validated math-SDPA path.

Both halves together cover the same 900 validation inputs. No checkpoint,
processor, prompt, image, decoding policy, or answer is changed.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
import zipfile

OLD = Path('/root/private_data/guoxin-session010')
BASE = Path('/root/private_data/guoxin-session013')
HOOK = '''import json,os
from pathlib import Path
import torch
torch.backends.cuda.enable_flash_sdp(False)
torch.backends.cuda.enable_mem_efficient_sdp(False)
torch.backends.cuda.enable_math_sdp(True)
if hasattr(torch.backends.cuda,'enable_cudnn_sdp'):
    torch.backends.cuda.enable_cudnn_sdp(False)
r={'pid':os.getpid(),'torch':torch.__version__,'flash':torch.backends.cuda.flash_sdp_enabled(),
   'mem_efficient':torch.backends.cuda.mem_efficient_sdp_enabled(),'math':torch.backends.cuda.math_sdp_enabled()}
assert not r['flash'] and not r['mem_efficient'] and r['math']
Path(os.environ['KIMI_SDP_AUDIT_DIR'],str(os.getpid())+'.json').write_text(json.dumps(r))
'''


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024**2), b''):
            h.update(b)
    return h.hexdigest()


def rows(path):
    return [json.loads(x) for x in path.read_text().splitlines()]


def split(samples, index):
    ordered = sorted(samples, key=lambda s: hashlib.sha256(('kimi-full013:' + s['id']).encode()).digest())
    return ordered[index::2]


def dump(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2) + '\n')
    temp.replace(path)


def archive(out):
    target = Path('/root') / ('session013-kimi-' + out.name + '.zip')
    entries = []
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED) as z:
        for folder, dirs, files in os.walk(out, onerror=lambda e: (_ for _ in ()).throw(e)):
            dirs[:] = sorted(d for d in dirs if d != '__pycache__')
            for name in sorted(files):
                p = Path(folder) / name
                assert not p.is_symlink()
                rel = p.relative_to(out).as_posix()
                z.write(p, rel)
                entries.append({'path': rel, 'bytes': p.stat().st_size, 'sha256': sha(p)})
        z.writestr('MANIFEST.json', json.dumps({'files': entries}, indent=2))
    print(json.dumps({'archive': str(target), 'sha256': sha(target), 'files': len(entries)}), flush=True)


def run(args):
    assert sys.platform == 'linux' and Path('/dev/kfd').exists()
    data = OLD / 'mmmu'
    assert sha(data / 'samples.jsonl') == '90f833664dc9d0b4ce6b8ce1d9035aac89d6a1c153aa462995c5977af66017ea'
    samples = rows(data / 'samples.jsonl')
    assert len(samples) == len({s['id'] for s in samples}) == 900
    selected = sorted(samples, key=lambda s: hashlib.sha256(('kimi-full013:' + s['id']).encode()).digest()) if args.whole_dataset else split(samples, args.shard)
    expected_count = 900 if args.whole_dataset else 450
    assert len(selected) == expected_count
    previous = {s['id']: s for s in rows(OLD / 'kimi004/evaluation/predictions.jsonl')}
    assert len(previous) == 900
    max_prompt = max(r['raw_response']['usage']['prompt_tokens'] for r in previous.values())
    assert max_prompt + 4096 <= 8192
    out = BASE / (('whole' if args.whole_dataset else 'shard' + str(args.shard)) + '-attempt' + str(args.attempt))
    out.mkdir(parents=True, exist_ok=False)
    project = out / 'project'
    shutil.copytree(OLD / 'projects/kimi', project,
                    ignore=shutil.ignore_patterns('.git', '__pycache__', 'runtime', 'runtime-inherited-history'))
    driver = project / 'scripts/kimi_vl_runtime_005.py'
    original_sha = sha(driver)
    assert original_sha == 'faf5f7d4aabafaaee1be0916aa5257125d437c885cecfaae5e73cad472b0def4'
    text = driver.read_text()
    replacements = [
        ('runtime <= 6900', 'runtime <= 21600'),
        ('max 6900 seconds', 'max 21600 seconds'),
        ('"--max-num-seqs", "1"', '"--max-num-seqs", "' + str(args.sequences) + '"'),
        ('"--max-num-batched-tokens", str(length)', '"--max-num-batched-tokens", "4096"'),
        ('"max_num_seqs":1', '"max_num_seqs":' + str(args.sequences)),
    ]
    for old, new in replacements:
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    driver.write_text(text)
    task = project / 'tasks/kimi-vl-bw-vllm'
    hook = out / 'math-sdpa-hook'
    hook.mkdir()
    (hook / 'sitecustomize.py').write_text(HOOK)
    audit = out / 'math-sdpa-worker-audits'
    audit.mkdir()
    env = os.environ.copy()
    env.update(KIMI_MAX_LEN='8192', KIMI_MAX_RUNTIME_SECONDS='21600', KIMI_LOAD_TIMEOUT='1200',
               KIMI_SERVED_NAME='kimi-vl-a3b-instruct', VLLM_MLA_DISABLE='1',
               PYTHONPATH=str(hook) + ':' + str(project / 'scripts'), KIMI_SDP_AUDIT_DIR=str(audit),
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    run_id = uuid.uuid4().hex
    record = {'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'complete': False,
              'shard': 'all' if args.whole_dataset else args.shard, 'attempt': args.attempt, 'selected_ids': [s['id'] for s in selected],
              'selection': 'SHA256(kimi-full013:ID) order, alternating halves; no labels used',
              'dataset_samples': 900, 'shard_samples': expected_count, 'model_revision': '398eede0903cd983a2bfa0cc634e9ac1d843f375',
              'dataset_revision': '876ce5cb130f7f7e290ce4d9984357737d4db5cf',
              'max_num_seqs': args.sequences, 'HTTP_concurrency': 4, 'max_model_len': 8192,
              'max_previous_prompt_tokens': max_prompt, 'output_tokens': 4096, 'seed': 42,
              'original_driver_sha256': original_sha, 'driver_sha256': sha(driver),
              'source_sha256': sha(Path(__file__)), 'capacity_only_replacements': replacements,
              'run_id': run_id, 'phases': {}, 'submitted': False, 'official_acceptance': False}
    shutil.copyfile(Path(__file__), out / 'executed-controller.py')
    dump(out / 'run-progress.json', record)

    def step(argv, label, timeout):
        with (out / (label + '.log')).open('xb') as f:
            child = subprocess.Popen(argv, env=env, stdout=f, stderr=subprocess.STDOUT)
            try:
                code = child.wait(timeout=timeout)
            except BaseException:
                child.terminate()
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
                raise
        record['phases'][label] = code
        assert code == 0, label

    def interrupted(*_):
        raise TimeoutError('Six-hour owned-process cap')

    signal.signal(signal.SIGALRM, interrupted)
    signal.alarm(21600)
    try:
        for port in (30000, 30119, 30129, 30139):
            with socket.socket() as sock:
                assert sock.connect_ex(('127.0.0.1', port)) != 0, ('existing service', port)
        step([sys.executable, str(driver), 'launch', '--task-dir', str(task), '--run-id', run_id], 'launch', 1260)
        log = (task / 'runtime/server.log').read_text(errors='replace')
        assert 'Using FlashAttention prefill for MLA' not in log
        sys.path.insert(0, str(OLD / 'tools'))
        from evaluate_vlm003 import payload, decode_completion
        record['payload_source_sha256'] = sha(OLD / 'tools/evaluate_vlm003.py')
        record['service_ready_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()

        def request(sample):
            row = {'id': sample['id'], 'image_sha256': [i['sha256'] for i in sample['images']]}
            tick = time.perf_counter()
            try:
                body = payload(sample, data, 'mmmu', 'kimi-vl-a3b-instruct', 4096)
                raw = json.dumps(body, ensure_ascii=False).encode()
                row['request_sha256'] = hashlib.sha256(raw).hexdigest()
                assert row['request_sha256'] == previous[sample['id']]['request_sha256'], 'Original request identity differs'
                req = urllib.request.Request('http://127.0.0.1:30129/v1/chat/completions', raw, {'Content-Type': 'application/json'})
                with urllib.request.urlopen(req, timeout=600) as response:
                    value = json.loads(response.read(8 * 1024**2))
                row['raw_response'] = value
                row.update(decode_completion(value))
                assert value['usage']['prompt_tokens'] == previous[sample['id']]['raw_response']['usage']['prompt_tokens']
            except urllib.error.HTTPError as exc:
                row.update(status='failed', error=str(exc), error_body=exc.read(16384).decode(errors='replace'))
            except Exception as exc:
                row.update(status='failed', error=repr(exc))
            row['wall_seconds'] = time.perf_counter() - tick
            return row

        results = []
        with (out / 'predictions.jsonl').open('x') as f, ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(request, s) for s in selected]
            for future in as_completed(futures):
                row = future.result()
                results.append(row)
                f.write(json.dumps(row, ensure_ascii=False) + '\n')
                f.flush()
                if len(results) % 10 == 0:
                    progress = {'done': len(results), 'failed': sum(r['status'] != 'ok' for r in results),
                                'UTC': dt.datetime.now(dt.timezone.utc).isoformat()}
                    record['progress'] = progress
                    dump(out / 'run-progress.json', record)
                    print(json.dumps(progress), flush=True)
        record.update(complete=len(results) == expected_count and all(r['status'] == 'ok' for r in results),
                      count=len(results), failed_ids=[r['id'] for r in results if r['status'] != 'ok'])
    except BaseException as exc:
        record['error'] = repr(exc)
    finally:
        signal.alarm(0)
        try:
            step([sys.executable, str(driver), 'stop', '--task-dir', str(task), '--run-id', run_id], 'stop', 90)
        except Exception as exc:
            record['cleanup_error'] = repr(exc)
        with socket.socket() as sock:
            record['owned_service_stopped'] = sock.connect_ex(('127.0.0.1', 30129)) != 0
        record['ended_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        dump(out / 'run-final.json', record)
        archive(out)
        print(json.dumps(record), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--shard', type=int, choices=(0, 1))
    parser.add_argument('--whole-dataset', action='store_true')
    parser.add_argument('--attempt', type=int, choices=(1, 2, 3), default=1)
    parser.add_argument('--sequences', type=int, choices=(1, 2, 4), default=4)
    parser.add_argument('--selfcheck', action='store_true')
    args = parser.parse_args()
    if args.selfcheck:
        fake = [{'id': str(i)} for i in range(900)]
        a, b = split(fake, 0), split(fake, 1)
        assert len(a) == len(b) == 450
        assert {s['id'] for s in a}.isdisjoint({s['id'] for s in b})
        assert {s['id'] for s in a + b} == {s['id'] for s in fake}
        compile(HOOK, 'math-sitecustomize.py', 'exec')
        print(json.dumps({'split_coverage': 900, 'overlap': 0, 'hook_syntax': True, 'GPU_executed': False}))
        return
    assert args.whole_dataset != (args.shard is not None), 'Choose whole dataset or one shard'
    run(args)


if __name__ == '__main__':
    main()
