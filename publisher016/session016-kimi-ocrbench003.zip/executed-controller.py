"""Full OCRBench1000 on the verified math-SDPA candidate, after AuK releases B."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import ast
import argparse
import base64
import datetime as dt
import hashlib
import importlib.util
import io
import json
import mimetypes
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
import zipfile

OLD = Path('/root/private_data/guoxin-session010')
STAGE = Path('/root/private_data/guoxin-session016/ocr-stage001')
OUT = Path('/root/private_data/guoxin-session016/kimi-ocrbench001')
AUK = Path('/root/private_data/guoxin-session014/auk-batch-one-full015')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    global OUT
    assert Path('/dev/kfd').exists()
    parser = argparse.ArgumentParser()
    parser.add_argument('--after-robo',action='store_true')
    parser.add_argument('--attempt',type=int,default=1)
    args = parser.parse_args()
    assert 1 <= args.attempt <= 9
    OUT = OUT.with_name('kimi-ocrbench' + str(args.attempt).zfill(3))
    prior_dir = Path('/root/private_data/guoxin-session014/robo-spatial-full015') if args.after_robo else AUK
    prior_pid = 3627 if args.after_robo else 3175
    prior_name = 'run_robo_spatial015.py' if args.after_robo else 'auk_full1088_request015.py'
    prior_zip = '/root/session014-robo-spatial-full015.zip' if args.after_robo else '/root/session014-auk-batch-one-full015.zip'
    deadline = time.monotonic() + 21600
    while True:
        process = Path('/proc') / str(prior_pid) / 'cmdline'
        alive = process.exists() and prior_name in process.read_text(errors='replace')
        if (prior_dir / 'run-final.json').is_file() and not alive:
            prior = json.loads((prior_dir / 'run-final.json').read_text())
            assert prior.get('owned_service_stopped') if args.after_robo else prior.get('service_stopped')
            with zipfile.ZipFile(prior_zip) as bundle:
                assert bundle.testzip() is None
            break
        assert alive and time.monotonic() < deadline, 'Prior job lacks a final archive; leave existing processes untouched'
        print(json.dumps({'waiting_for_prior_job':prior_name,'UTC':dt.datetime.now(dt.timezone.utc).isoformat()}),flush=True)
        time.sleep(30)
    data = STAGE / 'data'
    identity = json.loads((data / 'READY.json').read_text())
    assert sha(data / 'samples.jsonl') == identity['samples_sha256']
    assert sha(data / 'annotations.json') == identity['annotations_sha256']
    samples = [json.loads(x) for x in (data / 'samples.jsonl').read_text().splitlines()]
    annotations = json.loads((data / 'annotations.json').read_text())
    assert len(samples) == len({s['id'] for s in samples}) == len(annotations) == 1000
    for port in (30000,30001,30002,30109,30119,30129,30139):
        with socket.socket() as sock:
            assert sock.connect_ex(('127.0.0.1',port)) != 0, ('Other service is active',port)
    sys.path.insert(0,str(STAGE / 'tools'))
    from kimi_mmmu_full014 import HOOK
    OUT.mkdir(parents=True,exist_ok=False)
    project = OUT / 'project'
    shutil.copytree(OLD / 'projects/kimi',project,ignore=shutil.ignore_patterns('.git','runtime','__pycache__','runtime-inherited-history'))
    driver = project / 'scripts/kimi_vl_runtime_005.py'
    assert sha(driver) == 'faf5f7d4aabafaaee1be0916aa5257125d437c885cecfaae5e73cad472b0def4'
    code = driver.read_text()
    for before,after in [('runtime <= 6900','runtime <= 21600'),('max 6900 seconds','max 21600 seconds'),
                         ('"--max-num-seqs", "1"','"--max-num-seqs", "4"'),
                         ('"--max-num-batched-tokens", str(length)','"--max-num-batched-tokens", "4096"'),
                         ('"max_num_seqs":1','"max_num_seqs":4')]:
        assert code.count(before) == 1,before
        code = code.replace(before,after)
    driver.write_text(code)
    task = project / 'tasks/kimi-vl-bw-vllm'
    hook = OUT / 'math-sdpa-hook'
    hook.mkdir()
    (hook / 'sitecustomize.py').write_text(HOOK)
    audit = OUT / 'math-sdpa-worker-audits'
    audit.mkdir()
    env = os.environ.copy()
    # SSH sessions do not inherit the DTK loader paths from Jupyter's service.
    dtk_libraries = ['/opt/ucx/lib','/opt/dtk/dcc/gcvm/lib','/opt/dtk/hip/lib',
                     '/opt/dtk/llvm/lib','/opt/dtk/lib','/opt/dtk/lib64',
                     '/opt/hyhal/lib','/opt/hyhal/lib64','/opt/dtk/dushmem/lib',
                     '/opt/dtk/opencl/lib','/opt/mpi/lib','/opt/hwloc/lib']
    assert Path('/opt/dtk/hip/lib/libgalaxyhip.so.5').exists()
    env['LD_LIBRARY_PATH'] = ':'.join(dtk_libraries + [env.get('LD_LIBRARY_PATH','')])
    env.update(ROCM_PATH='/opt/dtk',HIP_PATH='/opt/dtk/hip')
    env['PATH'] = '/opt/ucx/bin:/opt/dtk/bin:/opt/dtk/llvm/bin:/opt/dtk/hip/bin:/opt/hyhal/bin:' + env.get('PATH','/usr/bin:/bin')
    env.update(KIMI_MAX_LEN='32768',KIMI_MAX_RUNTIME_SECONDS='21600',KIMI_LOAD_TIMEOUT='1200',
               KIMI_SERVED_NAME='kimi-vl-a3b-instruct',VLLM_MLA_DISABLE='1',
               KIMI_SDP_AUDIT_DIR=str(audit),PYTHONPATH=str(hook)+':'+str(project / 'scripts'),
               HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    run_id = uuid.uuid4().hex
    record = {'started_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'run_id':run_id,
              'dataset_identity':identity,'model_revision':'398eede0903cd983a2bfa0cc634e9ac1d843f375',
              'source_sha256':sha(Path(__file__)),'driver_sha256':sha(driver),
              'complete':False,'phases':{},'submitted':False,'official_acceptance':False,
              'max_model_len':32768,'HTTP_concurrency':4,'max_num_seqs':4,
              'decoding':{'temperature':0,'top_p':1,'max_tokens':4096,'seed':42}}
    shutil.copyfile(Path(__file__),OUT / 'executed-controller.py')
    (OUT / 'run-start.json').write_text(json.dumps(record,indent=2))
    def step(argv,label,timeout):
        with (OUT / (label+'.log')).open('xb') as log:
            child = subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,env=env)
            try:
                value = child.wait(timeout=timeout)
            except BaseException:
                child.terminate()
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
                raise
        record['phases'][label] = value
        assert value == 0,(label,value)
    try:
        step([sys.executable,str(driver),'launch','--task-dir',str(task),'--run-id',run_id],'launch',1260)
        from PIL import Image
        def request(sample):
            result = {'id':sample['id'],'image_sha256':sample['image_sha256']}
            tick = time.perf_counter()
            try:
                path = (data / sample['image']).resolve()
                assert path.is_relative_to(data.resolve()) and sha(path) == sample['image_sha256']
                image = Image.open(path)
                if image.mode == 'RGBA':
                    image = Image.alpha_composite(Image.new('RGBA',image.size,(255,255,255,255)),image).convert('RGB')
                image_buffer = io.BytesIO()
                image.convert('RGB').save(image_buffer,format=sample['image_format'])
                mime = mimetypes.guess_type(path.name)[0] or 'image/jpeg'
                content = [{'type':'image_url','image_url':{'url':'data:'+mime+';base64,'+base64.b64encode(image_buffer.getvalue()).decode()}},
                           {'type':'text','text':sample['question']}]
                body = dict(record['decoding'],model='kimi-vl-a3b-instruct',messages=[{'role':'user','content':content}],stream=False)
                raw = json.dumps(body,ensure_ascii=False).encode()
                result['request_sha256'] = hashlib.sha256(raw).hexdigest()
                req = urllib.request.Request('http://127.0.0.1:30129/v1/chat/completions',raw,{'Content-Type':'application/json'})
                with urllib.request.urlopen(req,timeout=600) as response:
                    value = json.loads(response.read(8*1024**2))
                result['raw_response'] = value
                choice = value['choices'][0]
                assert choice['finish_reason'] in ('stop','length') and isinstance(choice['message']['content'],str)
                result.update(status='ok',text=choice['message']['content'],finish_reason=choice['finish_reason'])
            except urllib.error.HTTPError as exc:
                result.update(status='failed',error=str(exc),error_body=exc.read(16384).decode(errors='replace'))
            except Exception as exc:
                result.update(status='failed',error=repr(exc))
            result['wall_seconds'] = time.perf_counter()-tick
            return result
        predictions = []
        with (OUT / 'predictions.jsonl').open('x') as log, ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(request,s) for s in samples]
            for future in as_completed(futures):
                row = future.result()
                predictions.append(row)
                log.write(json.dumps(row,ensure_ascii=False)+'\n')
                log.flush()
                if len(predictions)%25 == 0:
                    print(json.dumps({'done':len(predictions),'failed':sum(r['status']!='ok' for r in predictions)}),flush=True)
        record['generation_complete'] = len(predictions) == 1000 and all(r['status']=='ok' for r in predictions)
        if record['generation_complete']:
            mapping = {r['id']:r for r in predictions}
            frame = [dict(a,prediction=mapping[a['id']]['text'],answer=repr(a['answer'])) for a in annotations]
            class Frame:
                iloc = frame
                def __len__(self):
                    return len(frame)
            source = STAGE / 'sources/vlmeval-image-vqa.py'
            tree = ast.parse(source.read_text())
            cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name == 'OCRBench')
            namespace = {'ImageBaseDataset':object,'load':lambda _:Frame(),'tqdm':lambda x:x,
                         'eval':ast.literal_eval,'get_intermediate_file_path':lambda *x:OUT / 'score.json',
                         'dump':lambda value,p:Path(p).write_text(json.dumps(value,indent=2))}
            exec(compile(ast.Module(body=[cls],type_ignores=[]),'<pinned OCRBench class>','exec'),namespace)
            score = namespace['OCRBench'].evaluate(OUT / 'predictions.jsonl')
            record.update(complete=True,score=score,numeric_comparison_pass=score['Final Score'] >= 847,
                          scorer_source_sha256=sha(source),labels_sent_to_model=False,
                          max_prompt_tokens=max(r['raw_response']['usage']['prompt_tokens'] for r in predictions),
                          budget_exhausted=sum(r['finish_reason']=='length' for r in predictions))
    except BaseException as exc:
        record['error'] = repr(exc)
    finally:
        try:
            step([sys.executable,str(driver),'stop','--task-dir',str(task),'--run-id',run_id],'stop',90)
        except BaseException as exc:
            record['cleanup_error'] = repr(exc)
        with socket.socket() as sock:
            record['owned_service_stopped'] = sock.connect_ex(('127.0.0.1',30129)) != 0
        record['ended_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        (OUT / 'run-final.json').write_text(json.dumps(record,indent=2))
        files = []
        with zipfile.ZipFile('/root/session016-' + OUT.name + '.zip','x',zipfile.ZIP_DEFLATED) as bundle:
            for folder,dirs,names in os.walk(OUT,onerror=lambda e:(_ for _ in ()).throw(e)):
                dirs[:] = sorted(d for d in dirs if d != '__pycache__')
                for name in sorted(names):
                    p = Path(folder)/name
                    assert not p.is_symlink()
                    rel = p.relative_to(OUT).as_posix()
                    bundle.write(p,rel)
                    files.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
            bundle.writestr('MANIFEST.json',json.dumps({'files':files},indent=2))
        print(json.dumps(record),flush=True)


if __name__ == '__main__':
    main()
