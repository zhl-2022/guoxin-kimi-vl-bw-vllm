from pathlib import Path
import hashlib,json,os,runpy
runpy.run_path(os.environ['KIMI_CLIENT_MATH_HOOK'])
from transformers import AutoProcessor
_load_processor = AutoProcessor.from_pretrained
def _kimi_image_id(*args,**kwargs):
    processor = _load_processor(*args,**kwargs)
    if type(processor).__name__ == 'KimiVLProcessor':
        assert str(args[0]) == '/root/private_data/guoxin-candidates/models/kimi-vl'
        assert processor.image_token == '<|media_pad|>'
        token_id = processor.tokenizer.convert_tokens_to_ids(processor.image_token)
        assert processor.tokenizer.convert_ids_to_tokens(token_id) == processor.image_token
        previous = getattr(processor,'image_token_id',None)
        assert previous is None or previous == token_id
        processor.image_token_id = token_id
        row = {'pid':os.getpid(),'processor':type(processor).__name__,'previous_image_token_id':previous,
               'image_token_id':token_id,'image_token':processor.image_token,
               'model_files_changed':False,'upstream_sglang_source_changed':False}
        with Path(os.environ['KIMI_CLIENT_COMPAT_AUDIT']).open('a') as stream:
            stream.write(json.dumps(row)+'\n')
    return processor
AutoProcessor.from_pretrained = _kimi_image_id
