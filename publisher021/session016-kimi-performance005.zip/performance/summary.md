# SGLang client performance record

Official acceptance: false. upstream output_lens may use stream usage or requested-length fallback; exact 1024-token output is not independently certified
Configured server framework: vllm. Upstream client sender alias: sglang-oai-chat; OpenAI /v1/chat/completions. SGLang0.5.12 image dataset permits sglang-oai-chat, not vllm-chat; both aliases map to the same upstream OpenAI chat sender. The sender alias does not identify the server framework or create a SGLang-serving contest piece.

| Round | Text target | Concurrency | Completed | Output token/s | Mean TTFT ms | Client wall s | Status |
|---|---|---|---|---|---|---|---|
| 1 | 4096 | 1 |  |  |  | 594.186152 | invalid_native_result |
| 2 | 4096 | 1 |  |  |  | 590.638239 | invalid_native_result |
| 1 | 4096 | 8 |  |  |  | 347.858115 | invalid_native_result |
| 2 | 4096 | 8 |  |  |  | 338.989474 | invalid_native_result |
| 1 | 4096 | 64 |  |  |  | 2541.494164 | invalid_native_result |
| 2 | 4096 | 64 |  |  |  | 2539.035043 | invalid_native_result |
| 1 | 16384 | 1 |  |  |  | 689.080753 | invalid_native_result |
| 2 | 16384 | 1 |  |  |  | 683.859863 | invalid_native_result |
| 1 | 16384 | 8 |  |  |  | 788.727658 | invalid_native_result |
| 2 | 16384 | 8 |  |  |  | 784.919829 | invalid_native_result |
| 1 | 16384 | 64 |  |  |  | 3485.93223 | interrupted |
| 2 | 16384 | 64 |  |  |  |  | not_attempted_interrupted |
